let plantHeight1 = 0; //starting height of flower 1
let maxHeight1 = 125; //max height of the flower 1
let plantHeight2 = 0; //starting height of flower 2
let maxHeight2 = 125; //max height of the flower 2
let plantHeight3 = 0; //starting height of flower 3
let maxHeight3 = 125; //max height of the flower 3
let plantHeight4 = 0; //starting height of flower 4
let maxHeight4 = 125; //max height of the flower 4
let dirtX = 100; // X position of dirt
let dirtY = 250; // Y position of dirt
let clouds1 = 0;
let speed = 0.1;
//Glitch
let glitch; //glitch
let glitch1; //glitch 2
let img; //img
let img1; // img
let img2;
let glitching = false; // This so it allows the img to glitch
let glitchIntensity = 0; // Sets the intensity of the glitch
let showImg = false; //boolan for img
let sounds = []; //array for the sounds
let soundState = 0; //sound state
let imgPopup = false; // for win screen
let loadgif;
let invertpls = false;

//preloading all imgs and sounds
function preload() {
  img = loadImage("ryanglitch.png");
  img1 = loadImage("bloodyscreen.png");
  img2 = loadImage("happyscreen.png");
  loadgif = loadImage("happyscreen.gif");
  sounds.push(loadSound("garden.mp3"));
  sounds.push(loadSound("fnaf.mp3"));
  sounds.push(loadSound("gardenreversed.mp3"));
  sounds.push(loadSound("daytime.mp3"));
}
function setup() {
  createCanvas(700, 600);
  //creates new glitch
  glitch = new Glitch();
  glitch1 = new Glitch();
  //loads img to glitch
  glitch.loadImage(img);
  glitch1.loadImage(img1);
  glitch.loadImage("ryanglitch.png");
  glitch1.loadImage("ryanyang.png");
  imageMode(CENTER);
  //plays the first sound which is clair de lune
  sounds[soundState].play();
}

function draw() {
  background("rgb(0,0,0)");
  //path
  push();
  translate(0, 200);
  noStroke();
  fill("#3D743F");
  rect(0, 0, 700, 600);
  pop();
  //clouds
  clouds();
  //dirt
  push();
  noStroke();
  fill("#6F5555");
  rect(dirtX, dirtY, 200, 100);
  rect(dirtX + 300, dirtY, 200, 100);
  rect(dirtX, dirtY + 200, 200, 100);
  rect(dirtX + 300, dirtY + 200, 200, 100);
  pop();
  //Flowers used in For Loops so i can make copies of them without making more code
  push();
  for (let w = 1; w < 4; w++) {
    push();
    push();
    scale(0.5);
    Flowers1(100 + 150 * w, 600, 650);
    pop();
    pop();
  }
  for (let w = 1; w < 4; w++) {
    push();
    push();
    scale(0.5);
    Flowers2(100 + 150 * w, 1000, 1050);
    pop();
    pop();
  }
  for (let w = 1; w < 4; w++) {
    push();
    push();
    scale(0.5);
    Flowers3(700 + 150 * w, 1000, 1050);
    pop();
    pop();
  }
  for (let w = 1; w < 4; w++) {
    push();
    push();
    scale(0.5);
    Flowers4(700 + 150 * w, 600, 650);
    pop();
    pop();
  }
  pop();
  //me
  push();
  scale(0.5);
  translate(100, 0);
  me();
  pop();
  //speech bubble
  dialogue();

  push();
  angryMe();
  pop();
  //so image can pop up
  if (imgPopup) {
    push();
    image(loadgif, width / 2, height / 2, width, height);
    pop();
  }
  //Water Bucket
  push();
  wateringCan();
  pop();
  //finish
  //use this to invert the whole thing to make it look creepy only if invertpls is true and sound state is at 2
  if (invertpls && soundState == 2) {
    filter(INVERT);
  } else {
    invertpls = false;
  }
}
//these functions are used to make the designs and actually making it grow
function Flowers1(plantXpos, plantYpos, plantYpos2) {
  push();
  //   make sunflower
  if (plantHeight1 == maxHeight1) {
    //     //     petals
    //petals
    push();
    fill("#9C27B0");
    strokeWeight(0);

    circle(plantXpos + 50, plantYpos2 - 40 - plantHeight1, 70);
    circle(plantXpos - 20, plantYpos2 + 30 - plantHeight1, 70);
    circle(plantXpos + 45, plantYpos2 + 30 - plantHeight1, 70);
    circle(plantXpos - 20, plantYpos2 - 40 - plantHeight1, 70);
    pop();
    fill(50, 205, 50);
    ellipse(plantXpos - 10, plantYpos, 50, 20);
    ellipse(plantXpos + 30, plantYpos, 50, 20);
    pop();
  }
  noStroke();
  // draw the plant stem
  fill(0, 100, 0);
  rect(plantXpos, plantYpos2 - plantHeight1, 20, plantHeight1);

  if (mouseX > 100 && mouseX < 300 && mouseY > 250 && mouseY < 350) {
    if (mouseIsPressed && plantHeight1 < maxHeight1) {
      plantHeight1 += 0.5;
    }
  }

  push();
  fill("rgb(87,20,20)");
  circle(plantXpos + 10, plantYpos2 - plantHeight1, 70);
  pop();
}
function Flowers2(plantXpos, plantYpos, plantYpos2) {
  push();
  //   make sunflower
  if (plantHeight2 == maxHeight2) {
    //     //     petals
    //petals
    push();
    fill("#5767C0");
    strokeWeight(0);

    circle(plantXpos + 50, plantYpos2 - 40 - plantHeight2, 70);
    circle(plantXpos - 20, plantYpos2 + 30 - plantHeight2, 70);
    circle(plantXpos + 45, plantYpos2 + 30 - plantHeight2, 70);
    circle(plantXpos - 20, plantYpos2 - 40 - plantHeight2, 70);
    pop();
    fill(50, 205, 50);
    ellipse(plantXpos - 10, plantYpos, 50, 20);
    ellipse(plantXpos + 30, plantYpos, 50, 20);
    pop();
  }
  noStroke();
  // draw the plant stem
  fill(0, 100, 0);
  rect(plantXpos, plantYpos2 - plantHeight2, 20, plantHeight2);

  if (mouseX > 100 && mouseX < 300 && mouseY > 450 && mouseY < 550) {
    if (mouseIsPressed && plantHeight2 < maxHeight2) {
      plantHeight2 += 0.5;
    }
  }

  push();
  fill("rgb(87,20,20)");
  circle(plantXpos + 10, plantYpos2 - plantHeight2, 70);
  pop();
}
function Flowers3(plantXpos, plantYpos, plantYpos2) {
  push();
  //   make sunflower
  if (plantHeight3 == maxHeight3) {
    //     //     petals
    //petals
    push();
    fill("#F66B9A");
    strokeWeight(0);

    circle(plantXpos + 50, plantYpos2 - 40 - plantHeight3, 70);
    circle(plantXpos - 20, plantYpos2 + 30 - plantHeight3, 70);
    circle(plantXpos + 45, plantYpos2 + 30 - plantHeight3, 70);
    circle(plantXpos - 20, plantYpos2 - 40 - plantHeight3, 70);
    pop();
    fill(50, 205, 50);
    ellipse(plantXpos - 10, plantYpos, 50, 20);
    ellipse(plantXpos + 30, plantYpos, 50, 20);
    pop();
  }
  noStroke();
  // draw the plant stem
  fill(0, 100, 0);
  rect(plantXpos, plantYpos2 - plantHeight3, 20, plantHeight3);

  if (mouseX > 400 && mouseX < 600 && mouseY > 450 && mouseY < 550) {
    if (mouseIsPressed && plantHeight3 < maxHeight3) {
      plantHeight3 += 0.5;
    }
  }

  push();
  fill("rgb(87,20,20)");
  circle(plantXpos + 10, plantYpos2 - plantHeight3, 70);
  pop();
}
function Flowers4(plantXpos, plantYpos, plantYpos2) {
  push();
  //   make sunflower
  if (plantHeight4 == maxHeight4) {
    //     //     petals
    //petals
    push();
    fill("#FFEB3B");
    strokeWeight(0);

    circle(plantXpos + 50, plantYpos2 - 40 - plantHeight4, 70);
    circle(plantXpos - 20, plantYpos2 + 30 - plantHeight4, 70);
    circle(plantXpos + 45, plantYpos2 + 30 - plantHeight4, 70);
    circle(plantXpos - 20, plantYpos2 - 40 - plantHeight4, 70);
    pop();
    fill(50, 205, 50);
    ellipse(plantXpos - 10, plantYpos, 50, 20);
    ellipse(plantXpos + 30, plantYpos, 50, 20);
    pop();
  }
  noStroke();
  // draw the plant stem
  fill(0, 100, 0);
  rect(plantXpos, plantYpos2 - plantHeight4, 20, plantHeight4);

  if (mouseX > 400 && mouseX < 600 && mouseY > 250 && mouseY < 350) {
    if (mouseIsPressed && plantHeight4 < maxHeight4) {
      plantHeight4 += 0.5;
    }
  }

  push();
  fill("rgb(87,20,20)");
  circle(plantXpos + 10, plantYpos2 - plantHeight4, 70);
  pop();
}
//This function creates the watering can that moves with the mouse
function wateringCan() {
  strokeWeight(2);
  //follows the cursor
  translate(mouseX - 120, mouseY - 110);
  //rotates the watercan giving it a watering effect
  if (mouseIsPressed) {
    translate(-50, 90);
    rotate(-35);
  }
  //the watering can
  push();
  rectMode(CENTER);
  angleMode(DEGREES);
  fill("lightblue");
  fill(90, 171, 197);
  quad(158, 145, 219, 147, 252, 205, 133, 204);
  rotate(-30);
  translate(-50, 100);
  rect(100, 100, 10, 60);
  push();
  translate(0, -35);
  ellipse(100, 100, 20, 10);
  pop();
  pop();
  noFill();
  curve(59, 156, 228, 161, 240, 185, 13, 180);
  pop();
}
//Just me
function me() {
  image(glitch.image, 170, 210, 325, 375);
}
//Each if statement is used to create a different combination of dialogue plus i cant spell dialogue correctly so I made it into the function
function dialogue() {
  push();
  noStroke();
  ellipse(350, 50, 200, 100);
  triangle(260, 60, 285, 75, 234, 92);
  text("Oh nO! I forgot to water my plants. ", 260, 50);
  text("Please help me. (Hold on the ", 260, 70);
  text("dirt patch to water) ", 300, 90);
  pop();
  if (plantHeight1 == maxHeight1) {
    push();
    noStroke();
    ellipse(350, 50, 200, 100);
    triangle(260, 60, 285, 75, 234, 92);
    text("Oh those are pretty. ", 260, 50);
    pop();
    // GLITCH EFFECT
    glitchTimer(1, 10000);
  }
  push();
  if (plantHeight2 == maxHeight2) {
    push();
    noStroke();
    ellipse(350, 50, 200, 100);
    triangle(260, 60, 285, 75, 234, 92);
    text("I don't remember planting those... ", 260, 50);
    pop();
    // GLITCH EFFECT
    glitchTimer(1, 10000);
  }
  push();
  if (plantHeight3 == maxHeight3) {
    push();
    noStroke();
    ellipse(350, 50, 200, 100);
    triangle(260, 60, 285, 75, 234, 92);
    text("That color is horrible. ", 260, 50);
    pop();
    push();
    // GLITCH EFFECT
    glitchTimer(1, 10000);
    pop();
  }
  push();
  if (plantHeight4 == maxHeight4) {
    push();
    noStroke();
    ellipse(350, 50, 200, 100);
    triangle(260, 60, 285, 75, 234, 92);
    text("In this world, IT'S KILL", 260, 50);
    text("OR BE KILLED", 260, 70);
    pop();
    push();
    // GLITCH EFFECT
    glitchTimer(1, 10000);
    pop();
  }
  push();
  if (plantHeight1 == maxHeight1 && plantHeight2 == maxHeight2) {
    push();
    noStroke();
    ellipse(350, 50, 200, 100);
    triangle(260, 60, 285, 75, 234, 92);
    text("WOw great job. ", 260, 50);
    pop();
    // GLITCH EFFECT
    glitchTimer(5, 1000);
  }
  push();
  if (plantHeight1 == maxHeight1 && plantHeight3 == maxHeight3) {
    push();
    noStroke();
    ellipse(350, 50, 200, 100);
    triangle(260, 60, 285, 75, 234, 92);
    text("You're getting a hang of it", 260, 50);
    pop();
    push();
    // GLITCH EFFECT
    glitchTimer(5, 1000);
    pop();
  }
  push();
  if (plantHeight1 == maxHeight1 && plantHeight4 == maxHeight4) {
    push();
    noStroke();
    ellipse(350, 50, 200, 100);
    triangle(260, 60, 285, 75, 234, 92);
    text("Want a cookie? 🍪", 260, 50);
    pop();
    push();
    // GLITCH EFFECT
    glitchTimer(5, 1000);
    pop();
  }
  push();
  if (plantHeight2 == maxHeight2 && plantHeight3 == maxHeight3) {
    push();
    noStroke();
    ellipse(350, 50, 200, 100);
    triangle(260, 60, 285, 75, 234, 92);
    text("Extreme pollination and", 260, 50);
    text("total domination! ", 260, 70);

    pop();
    push();
    // GLITCH EFFECT
    glitchTimer(5, 1000);
    pop();
  }
  push();
  if (plantHeight2 == maxHeight2 && plantHeight4 == maxHeight4) {
    push();
    noStroke();
    ellipse(350, 50, 200, 100);
    triangle(260, 60, 285, 75, 234, 92);
    text("The Zombies are coming 🌼🧟 ", 260, 50);
    pop();
    push();
    // GLITCH EFFECT
    glitchTimer(5, 1000);
    pop();
  }
  push();
  if (plantHeight3 == maxHeight3 && plantHeight4 == maxHeight4) {
    push();
    noStroke();
    ellipse(350, 50, 200, 100);
    triangle(260, 60, 285, 75, 234, 92);
    text("At his lips' touch she", 300, 30);
    text("blossomed for him like a flower", 260, 50);
    text("and the incarnation was complete.", 260, 70);
    pop();
    push();
    // GLITCH EFFECT
    glitchTimer(5, 1000);
    pop();
  }
  push();
  if (
    plantHeight1 == maxHeight1 &&
    plantHeight2 == maxHeight2 &&
    plantHeight3 == maxHeight3
  ) {
    push();
    noStroke();
    ellipse(350, 50, 200, 100);
    triangle(260, 60, 285, 75, 234, 92);
    text("What came first, the chicken or ", 260, 50);
    text("the egg? 🐔🥚", 260, 70);
    pop();
    push();
    // GLITCH EFFECT
    glitchTimer(10, 100);
    pop();
  }
  push();
  if (
    plantHeight1 == maxHeight1 &&
    plantHeight2 == maxHeight2 &&
    plantHeight4 == maxHeight4
  ) {
    push();
    noStroke();
    ellipse(350, 50, 200, 100);
    triangle(260, 60, 285, 75, 234, 92);
    text("Maybe touching one gives me", 260, 50);
    text("a power-up?", 260, 70);
    pop();
    push();
    // GLITCH EFFECT
    glitchTimer(10, 100);
    pop();
  }
  if (
    plantHeight1 == maxHeight1 &&
    plantHeight3 == maxHeight3 &&
    plantHeight4 == maxHeight4
  ) {
    push();
    noStroke();
    ellipse(350, 50, 200, 100);
    triangle(260, 60, 285, 75, 234, 92);
    text("Hopefully these aren't Pikmins...", 260, 50);
    pop();
    push();
    // GLITCH EFFECT
    glitchTimer(10, 100);
    pop();
  }
  push();
  if (
    plantHeight1 == maxHeight1 &&
    plantHeight2 == maxHeight2 &&
    plantHeight3 == maxHeight3 &&
    plantHeight4 == maxHeight4
  ) {
    image(glitch1.image, width / 2, height / 2, width, height);

    if (soundState !== 1) {
      for (let i = 0; i < sounds.length; i++) {
        sounds[i].stop();
      }
      sounds[1].setVolume(10);
      sounds[0].stop();
      sounds[1].play();
      soundState = 1;
    }
    continuing();
    // GLITCH EFFECT
    glitchTimer1(13, 100);
    pop();
  }
}
//the clouds are kinda used as a timer for some other thing
function clouds() {
  //   clouds
  let clouds = frameCount * 0.1;
  push();
  fill("black");
  noStroke();
  translate(30, 50);
  rect(clouds, 0, 100, 20, 10);

  translate(90, 50);
  rect(clouds, 0, 100, 20, 10);
  translate(-130, -100);
  rect(clouds1, 0, 100, 20, 10);
  pop();
  clouds1 += speed;
  // sun
  push();
  noStroke();
  fill("white");
  circle(700, 0, 200);
  pop();
}
//No peeking just more dialouges idk if i spelled it correctly...
function angryMe() {
  if (
    plantHeight1 == 0 &&
    plantHeight2 == 0 &&
    plantHeight3 == 0 &&
    plantHeight4 == 0 &&
    clouds1 >= 100
  ) {
    push();
    noStroke();
    ellipse(350, 50, 200, 100);
    triangle(260, 60, 285, 75, 234, 92);
    text("you should water the plant", 260, 50);
    pop();
  }

  if (
    plantHeight1 == 0 &&
    plantHeight2 == 0 &&
    plantHeight3 == 0 &&
    plantHeight4 == 0 &&
    clouds1 >= 200 &&
    clouds1 <= 300
  ) {
    push();
    noStroke();
    ellipse(350, 50, 200, 100);
    triangle(260, 60, 285, 75, 234, 92);
    text("Hey water the plants.", 260, 50);
    pop();
  }
  if (
    plantHeight1 == 0 &&
    plantHeight2 == 0 &&
    plantHeight3 == 0 &&
    plantHeight4 == 0 &&
    clouds1 >= 300 &&
    clouds1 <= 400
  ) {
    push();
    noStroke();
    ellipse(350, 50, 200, 100);
    triangle(260, 60, 285, 75, 234, 92);
    text("What are you doing?", 260, 50);
    pop();
  }
  if (
    plantHeight1 == 0 &&
    plantHeight2 == 0 &&
    plantHeight3 == 0 &&
    plantHeight4 == 0 &&
    clouds1 >= 400 &&
    clouds1 <= 500
  ) {
    push();

    // noStroke();
    // ellipse(350, 50, 200, 100);
    // triangle(260, 60, 285, 75, 234, 92);
    // text("you're useless", 260, 50);
    pop();
  }

  if (
    plantHeight1 == 0 &&
    plantHeight2 == 0 &&
    plantHeight3 == 0 &&
    plantHeight4 == 0 &&
    clouds1 > 500
  ) {
    push();
    if (soundState == 0 && soundState !== 2) {
      sounds[0].stop();
      sounds[3].play();
      soundState = 3;
      imgPopup = true;
    }
  }
  pop();
  // noStroke();
  // fill("black");
  // ellipse(350, 60, 260, 200);
  // triangle(275, 75, 290, 80, 235, 95);
  //mouth
  // pop();
  // push();
  // noStroke();
  // fill(255, 219, 172);
  // circle(150, 120, 45);
  // pop();
  // strokeWeight(2);
  // line(124, 119, 174, 119);
}

//new Code
//allows glitch to glitch and also makes sure to reset the glitch so a more intense glitch can happen we did this because apparently you cannot overlay a glitch on another img thats already glitching
function glitchTimer(intensity, duration) {
  //if intensity is more than glitchIntensity (0) or id its not glitching than it will glitch which means glitch.randomBytes will be active
  if (intensity > glitchIntensity || !glitching) {
    glitching = true;

    glitch.randomBytes(intensity);
    glitch.buildImage();
    //this is used to reset the Bytes so img is no longer distorted
    setTimeout(function () {
      glitch.resetBytes();
      glitching = false;
    }, duration);
  }
}
//made another one for another img
function glitchTimer1(intensity, duration) {
  if (intensity > glitchIntensity || !glitching) {
    glitching = true;

    glitch1.randomBytes(intensity);
    glitch1.buildImage();

    setTimeout(function () {
      glitch1.resetBytes();
      glitching = false;
    }, duration);
  }
}
//button creation
function continuing() {
  push();
  fill("maroon");
  rect(275, 520, 200, 100);
  push();
  textSize(20);
  fill("black");
  text("Continue?", 325, 570);
  pop();
}
//resets everything
function reset() {
  plantHeight1 = 0;
  plantHeight2 = 0;
  plantHeight3 = 0;
  plantHeight4 = 0;

  clouds1 = 0;
  glitch1.resetBytes();
  glitch.resetBytes();

  if (soundState == 1) {
    sounds[2].play();
    soundState = 2;
    invertpls = true;
  }
}
//horror shit
//when you press that continue button it will reset
function mousePressed() {
  if (
    plantHeight1 == maxHeight1 &&
    plantHeight2 == maxHeight2 &&
    plantHeight3 == maxHeight3 &&
    plantHeight4 == maxHeight4
  ) {
    if (mouseX > 275 && mouseX < 475 && mouseY > 520 && mouseY < 600) {
      reset();
    }
  }
}
