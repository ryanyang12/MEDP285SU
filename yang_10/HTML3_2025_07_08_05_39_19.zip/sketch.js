/*
 * @name Mouse 2D
 * @arialabel Two fuschia squares on a grey background. As the user’s mouse moves left, the squares rotate around each other in the left direction and vice versa as the user’s mouse moves right 
 * @description Moving the mouse changes the position and
 * size of each box.
 */
function setup() {
  createCanvas(720, 400);
  noStroke();
  rectMode(CENTER);
}

function draw() {
  background("black");
  push()
  fill("white");
  ellipse(mouseX, height / 2, mouseY / 2 + 10, mouseY / 2 + 10);
  pop()
  fill( random(255),random(255),random(255));
  let inverseX = width - mouseX;
  let inverseY = height - mouseY;
  ellipse(inverseX, height / 2, inverseY / 2 + 10, inverseY / 2 + 10);
}


// changed the background color and all of the other color. Instead of rect made it into ellipse and put one of the thing into a push pop