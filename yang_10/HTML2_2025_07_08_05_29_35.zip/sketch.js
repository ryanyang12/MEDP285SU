/*
 * @name Multiple Objects
 * @arialabel Four small white circles places randomly on a dark navy background that move in small amounts in various directions by itself like they are jittering 
 * @description Create a Jitter class, instantiate multiple objects,
 * and move it around the screen.
 */

let bug1; // Declare objects
let bug2;
let bug3;
let bug4;
let bug5;
let bug6;
let bug7;
let bug8;

function setup() {
  createCanvas(windowWidth, windowHeight);
  // Create object
  bug1 = new Jitter();
  bug2 = new Jitter();
  bug3 = new Jitter();
  bug4 = new Jitter();
  bug5 = new Jitter();
  bug6 = new Jitter();
  bug7 = new Jitter();
  bug8 = new Jitter();
}

function draw() {
  background(50, 89, 100);
  bug1.move();
  bug1.display();
  bug2.move();
  bug2.display();
  bug3.move();
  bug3.display();
  bug4.move();
  bug4.display();
    bug5.move();
  bug5.display();
    bug6.move();
  bug6.display();
    bug7.move();
  bug7.display();
    bug8.move();
  bug8.display();
  fill(random(255),random(255),random(255))
}

// Jitter class
class Jitter {
  constructor() {
    this.x = random(width);
    this.y = random(height);
    this.diameter = random(50, 30);
    this.speed = 5;
  }

  move() {
    this.x += random(-this.speed, this.speed);
    this.y += random(-this.speed, this.speed);
  }

  display() {
    rect(this.x, this.y, this.diameter, this.diameter);
  }
}

// added random to fill, made canvas bigger, made speed to jittering much faster, changed the shape use to be ellipse now is rect.
